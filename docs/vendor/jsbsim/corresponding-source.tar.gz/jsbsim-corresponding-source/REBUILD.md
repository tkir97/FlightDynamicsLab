# Corresponding source for the Flight Lab JSBSim WASM runtime

Runtime: JSBSim 1.2.4, upstream revision 1a2e114d79af2430db02a4f7a4a85328cdc5d403.
SDK/bindings/build: @0x62/jsbsim-wasm 1.2.4-beta.4, revision 8326145a50375e96ac952eac1dfce9a46ba75265.
The distributed binary is unchanged from that SDK release.

All JSBSim sources, the SDK source, generated Embind bindings, compatibility patches, and build configuration are included. JSBSim is LGPL-2.1; SDK is MIT. See vendor/jsbsim/COPYING and LICENSE.

Install and activate an Emscripten SDK and CMake 3.20+. From this extracted folder:

    git apply --directory=vendor/jsbsim patches/jsbsim-emscripten-compat.patch
    emcmake cmake -S cmake -B build/wasm -DJSBSIM_SOURCE_DIR="$PWD/vendor/jsbsim" -DJSBSIM_WASM_BINDINGS="$PWD/generated/FGFDMExecBindings.cpp" -DCMAKE_BUILD_TYPE=Release
    cmake --build build/wasm --target jsbsim_wasm --parallel

The above bypasses upstream's git submodule setup (this archive already includes the complete submodule sources). Replace dist/vendor/jsbsim/wasm/jsbsim_wasm.mjs and jsbsim_wasm.wasm with the rebuilt files. Flight Lab dynamically loads these separate files; no proprietary application objects are needed to replace the engine. Toolchain differences may change the binary byte-for-byte while preserving the interface.

To rebuild SDK JavaScript: npm ci; npm run build:sdk. Copy dist/index.js into the app as dist/vendor/jsbsim/sdk.mjs.
